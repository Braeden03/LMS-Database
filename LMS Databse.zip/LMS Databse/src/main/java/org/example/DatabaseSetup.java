package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * DatabaseSetup.java
 * This class sets up the SQLite database for the Library Management System.
 */
public class DatabaseSetup {

    /**
     * Main method to set up the SQLite database.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        String url = "jdbc:sqlite:C:/Users/Brady/IdeaProjects/LMS Databse/library.db";

        try (Connection conn = DriverManager.getConnection(url)) {
            if (conn != null) {
                Statement stmt = conn.createStatement();
                // Create books table
                stmt.execute("CREATE TABLE IF NOT EXISTS books (" +
                        "barcode TEXT PRIMARY KEY," +
                        "title TEXT NOT NULL," +
                        "author TEXT NOT NULL," +
                        "genre TEXT," +
                        "status TEXT NOT NULL," +
                        "due_date TEXT" +
                        ");");
                System.out.println("Database setup complete.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
