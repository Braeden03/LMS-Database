package org.example;

import java.sql.*;

public class DatabaseSetup {
    public static void main(String[] args) {
        String url = "jdbc:sqlite:C:/Users/Brady/IdeaProjects/LMS Databse/library.db";
        String sql = """
            CREATE TABLE IF NOT EXISTS books (
                barcode TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                genre TEXT NOT NULL,
                status TEXT NOT NULL,
                due_date TEXT
            );
        """;

        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {

            stmt.executeUpdate(sql);
            System.out.println("Table created or already exists.");
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
        }
    }
}

