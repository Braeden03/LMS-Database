package org.example;

import javax.swing.*;
import java.sql.*;

/**
 * LibraryManagementSystem.java
 * John Doe, CS101, July 14, 2024
 * This class is the main GUI interface for the Library Management System.
 * It connects to an SQLite database and allows the user to perform CRUD operations on books.
 */
public class LibraryManagementSystem extends JFrame {
    private Connection connection;
    private final JTextArea textArea;
    private final JTextField titleField;
    private final JTextField barcodeField;

    public LibraryManagementSystem() {
        // Initialize database connection
        initializeDBConnection();

        // GUI components
        setTitle("Library Management System");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        textArea = new JTextArea();
        textArea.setBounds(10, 10, 560, 200);
        add(textArea);

        JButton showBooksButton = new JButton("Show Books");
        showBooksButton.setBounds(10, 220, 150, 25);
        add(showBooksButton);

        JButton removeBookButton = new JButton("Remove Book");
        removeBookButton.setBounds(10, 250, 150, 25);
        add(removeBookButton);

        JButton checkOutBookButton = new JButton("Check Out Book");
        checkOutBookButton.setBounds(10, 280, 150, 25);
        add(checkOutBookButton);

        JButton checkInBookButton = new JButton("Check In Book");
        checkInBookButton.setBounds(10, 310, 150, 25);
        add(checkInBookButton);

        titleField = new JTextField();
        titleField.setBounds(170, 220, 200, 25);
        add(titleField);

        barcodeField = new JTextField();
        barcodeField.setBounds(170, 250, 200, 25);
        add(barcodeField);

        // Action listeners
        showBooksButton.addActionListener(e -> showBooks());
        removeBookButton.addActionListener(e -> removeBook());
        checkOutBookButton.addActionListener(e -> checkOutBook());
        checkInBookButton.addActionListener(e -> checkInBook());
    }

    /**
     * Initializes the database connection.
     */
    private void initializeDBConnection() {
        String url = "jdbc:sqlite:C:/Users/Brady/IdeaProjects/LMS Databse/library.db";
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection(url);
            System.out.println("Database connection established."); // Print confirmation
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method retrieves all books from the database and displays them in the text area.
     */
    private void showBooks() {
        textArea.setText("");
        if (connection != null) {
            try (Statement stmt = connection.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT * FROM books")) {
                while (rs.next()) {
                    textArea.append(rs.getString("barcode") + " - " +
                            rs.getString("title") + " by " +
                            rs.getString("author") + " [" +
                            rs.getString("genre") + "] - " +
                            rs.getString("status") + " (Due: " +
                            rs.getString("due_date") + ")\n");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            textArea.setText("Database connection failed.");
        }
    }

    /**
     * This method removes a book from the database based on title or barcode.
     */
    private void removeBook() {
        String title = titleField.getText();
        String barcode = barcodeField.getText();
        if (connection != null) {
            try (PreparedStatement pstmt = connection.prepareStatement("DELETE FROM books WHERE title = ? OR barcode = ?")) {
                pstmt.setString(1, title);
                pstmt.setString(2, barcode);
                pstmt.executeUpdate();
                showBooks();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * This method checks out a book by updating its status and due date.
     */
    private void checkOutBook() {
        String barcode = barcodeField.getText();
        if (connection != null) {
            try (PreparedStatement pstmt = connection.prepareStatement("UPDATE books SET status = 'checked out', due_date = date('now', '+14 days') WHERE barcode = ?")) {
                pstmt.setString(1, barcode);
                pstmt.executeUpdate();
                showBooks();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * This method checks in a book by updating its status and setting the due date to null.
     */
    private void checkInBook() {
        String barcode = barcodeField.getText();
        if (connection != null) {
            try (PreparedStatement pstmt = connection.prepareStatement("UPDATE books SET status = 'checked in', due_date = NULL WHERE barcode = ?")) {
                pstmt.setString(1, barcode);
                pstmt.executeUpdate();
                showBooks();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            System.out.println("Creating LibraryManagementSystem instance");
            LibraryManagementSystem lms = new LibraryManagementSystem();
            System.out.println("Setting GUI visible");
            lms.setVisible(true);
        });
    }

}
