DROP TABLE IF EXISTS books;
CREATE TABLE IF NOT EXISTS books (
    barcode TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    genre TEXT NOT NULL,
    status TEXT NOT NULL,
    due_date TEXT
);


INSERT OR IGNORE INTO books (barcode, title, author, genre, status, due_date) VALUES
('1', '1984', 'George Orwell', 'Dystopian', 'checked in', NULL),
('2', 'To Kill a Mockingbird', 'Harper Lee', 'Fiction', 'checked out', '2024-07-21'),
('3', 'A Brief History of Time', 'Stephen Hawking', 'Non-Fiction', 'checked in', NULL),
('4', 'The Lightning Thief', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('5', 'The Sea of Monsters', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('6', 'The Titans Curse', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('7', 'The Battle of the Labyrinth', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('8', 'The Last Olympian', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('9', 'The Chalice of the Gods', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('10', 'Wrath of the Triple Goddess', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('11', 'The Lost Hero', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('12', 'The Son of Neptune', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('13', 'The Mark of Athena', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('14', 'The House of Hades', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('15', 'The Blood of Olympus', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('16', 'The Red Pyramid', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('17', 'The Throne of Fire', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('18', 'The Serpents Shadow', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('19', 'The Sword of Summer', 'Rick Riordan', 'Science Fiction', 'checked in', NULL),
('20', 'The Hammer of Thor', 'Rick Riordan', 'Science Fiction', 'checked in', NULL);
